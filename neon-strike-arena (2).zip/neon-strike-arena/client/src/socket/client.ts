import {io,Socket} from 'socket.io-client';import {EVENTS} from '../../../shared/protocol';
export const socket:Socket=io({autoConnect:true,reconnection:true,reconnectionAttempts:8,reconnectionDelay:700});export {EVENTS};
