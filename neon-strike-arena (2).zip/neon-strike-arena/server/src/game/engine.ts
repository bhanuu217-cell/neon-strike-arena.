import { randomUUID } from 'node:crypto';
import type { MatchState, PlayerInput, PlayerState, ProjectileState } from '../../../shared/protocol.js';
import { COLORS } from '../../../shared/protocol.js';
import { WORLD,RULES,OBSTACLES } from '../../../shared/constants.js';
export class GameEngine {
 state:MatchState; private inputs=new Map<string,PlayerInput>(); private lastShot=new Map<string,number>(); private respawns=new Map<string,number>(); private startedAt=0; private lastTick=Date.now(); private countdownAt=0; private matchSeconds:number;
 constructor(code:string,matchSeconds=RULES.matchSeconds){this.matchSeconds=matchSeconds;this.state={roomCode:code,status:'waiting',players:[],projectiles:[],timeLeft:matchSeconds,winnerId:null,countdown:0,serverTime:Date.now()};}
 addPlayer(id:string,name:string){if(this.state.players.length>=4)throw Error('Room is full');if(this.state.players.some(p=>p.id===id))return;const i=this.state.players.length;this.state.players.push({id,name,x:WORLD.width/2+(i%2?300:-300),y:WORLD.height/2+(i<2?-180:180),angle:0,health:RULES.maxHealth,kills:0,deaths:0,color:COLORS[i],connected:true,invulnerableUntil:0});}
 removePlayer(id:string){this.state.players=this.state.players.filter(p=>p.id!==id);this.inputs.delete(id);this.state.projectiles=this.state.projectiles.filter(p=>p.ownerId!==id);}
 setConnected(id:string,v:boolean){const p=this.player(id);if(p)p.connected=v;}
 setInput(id:string,input:PlayerInput){if(this.player(id))this.inputs.set(id,input);}
 player(id:string){return this.state.players.find(p=>p.id===id);}
 start(){if(this.state.players.filter(p=>p.connected).length<2)throw Error('At least two connected players are required');if(this.state.status==='playing'||this.state.status==='countdown')return;this.state.status='countdown';this.countdownAt=Date.now();this.state.countdown=5;this.state.players.forEach(p=>{p.kills=0;p.deaths=0;p.health=100;});this.state.projectiles=[];this.state.winnerId=null;}
 rematch(){this.state.status='waiting';this.state.timeLeft=this.matchSeconds;this.state.winnerId=null;this.state.projectiles=[];this.state.players.forEach(p=>{p.kills=0;p.deaths=0;p.health=100;});}
 tick(now=Date.now()) {const dt=Math.min((now-this.lastTick)/1000,.05);this.lastTick=now;this.state.serverTime=now;
  if(this.state.status==='countdown'){const elapsed=(now-this.countdownAt)/1000;this.state.countdown=Math.max(0,5-Math.floor(elapsed));if(elapsed>=5){this.state.status='playing';this.startedAt=now;this.lastTick=now;}return;}
  if(this.state.status!=='playing')return;this.state.timeLeft=Math.max(0,this.matchSeconds-(now-this.startedAt)/1000);
  for(const p of this.state.players){if(!p.connected)continue;const input=this.inputs.get(p.id);if(!input)continue;let dx=Number(input.right)-Number(input.left),dy=Number(input.down)-Number(input.up);const len=Math.hypot(dx,dy)||1;dx/=len;dy/=len;const nextX=Math.max(RULES.playerRadius,Math.min(WORLD.width-RULES.playerRadius,p.x+dx*RULES.playerSpeed*dt));const nextY=Math.max(RULES.playerRadius,Math.min(WORLD.height-RULES.playerRadius,p.y+dy*RULES.playerSpeed*dt));const blocked=(x:number,y:number)=>OBSTACLES.some(o=>{const cx=Math.max(o.x,Math.min(x,o.x+o.w)),cy=Math.max(o.y,Math.min(y,o.y+o.h));return Math.hypot(x-cx,y-cy)<RULES.playerRadius;});if(!blocked(nextX,p.y))p.x=nextX;if(!blocked(p.x,nextY))p.y=nextY;p.angle=Math.atan2(input.aimY-p.y,input.aimX-p.x);
   if(input.shoot&&now-(this.lastShot.get(p.id)||0)>=RULES.shootCooldown&&this.state.projectiles.filter(b=>b.ownerId===p.id).length<RULES.maxProjectiles){this.lastShot.set(p.id,now);const a=p.angle;this.state.projectiles.push({id:randomUUID(),ownerId:p.id,x:p.x+Math.cos(a)*28,y:p.y+Math.sin(a)*28,vx:Math.cos(a)*RULES.projectileSpeed,vy:Math.sin(a)*RULES.projectileSpeed,bornAt:now});}}
  this.state.projectiles=this.state.projectiles.filter(b=>{b.x+=b.vx*dt;b.y+=b.vy*dt;if(now-b.bornAt>RULES.projectileLife||b.x<0||b.y<0||b.x>WORLD.width||b.y>WORLD.height)return false;if(OBSTACLES.some(o=>b.x>o.x&&b.x<o.x+o.w&&b.y>o.y&&b.y<o.y+o.h))return false;for(const target of this.state.players){if(target.id===b.ownerId||target.health<=0||!target.connected||now<target.invulnerableUntil)continue;if(Math.hypot(target.x-b.x,target.y-b.y)<RULES.playerRadius+RULES.projectileRadius){target.health=Math.max(0,target.health-25);if(target.health===0){target.deaths++;const killer=this.player(b.ownerId);if(killer)killer.kills++;this.respawns.set(target.id,now+RULES.respawnMs);}return false;}}return true;});
  for(const [id,at] of this.respawns){if(now>=at){const p=this.player(id);if(p){p.health=100;p.x=160+Math.random()*1280;p.y=120+Math.random()*760;p.invulnerableUntil=now+RULES.invulnerabilityMs;}this.respawns.delete(id);}}
  const leader=this.state.players.find(p=>p.kills>=RULES.winKills);if(leader){this.finish(leader.id);}else if(this.state.timeLeft<=0){const winner=[...this.state.players].sort((a,b)=>b.kills-a.kills||a.deaths-b.deaths)[0];this.finish(winner?.id??null);}
 }
 private finish(id:string|null){this.state.status='finished';this.state.winnerId=id;this.state.projectiles=[];}
 snapshot():MatchState{return structuredClone(this.state);}
}
