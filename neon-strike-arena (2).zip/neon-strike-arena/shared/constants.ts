export const WORLD={width:1600,height:1000};
export const RULES={playerRadius:22,playerSpeed:280,projectileSpeed:720,projectileRadius:7,projectileLife:1800,shootCooldown:260,maxProjectiles:8,maxHealth:100,respawnMs:1800,invulnerabilityMs:1400,matchSeconds:180,winKills:10,tickRate:30,broadcastRate:20};
export const OBSTACLES=[{x:340,y:230,w:150,h:40},{x:1110,y:230,w:150,h:40},{x:340,y:730,w:150,h:40},{x:1110,y:730,w:150,h:40},{x:760,y:420,w:80,h:160},{x:590,y:470,w:80,h:60},{x:930,y:470,w:80,h:60}];
