import { z } from 'zod';
export const COLORS=['#42e8ff','#c66bff','#ff4fbd','#b8ff62'] as const;
export const inputSchema=z.object({up:z.boolean(),down:z.boolean(),left:z.boolean(),right:z.boolean(),aimX:z.number().finite().min(0).max(1600),aimY:z.number().finite().min(0).max(1000),shoot:z.boolean()}).strict();
export type PlayerInput=z.infer<typeof inputSchema>;
export interface PlayerState {id:string;name:string;x:number;y:number;angle:number;health:number;kills:number;deaths:number;color:string;connected:boolean;invulnerableUntil:number}
export interface ProjectileState {id:string;ownerId:string;x:number;y:number;vx:number;vy:number;bornAt:number}
export interface MatchState {roomCode:string;status:'waiting'|'countdown'|'playing'|'finished';players:PlayerState[];projectiles:ProjectileState[];timeLeft:number;winnerId:string|null;countdown:number;serverTime:number}
export interface RoomSummary {code:string;players:{id:string;name:string;connected:boolean}[];hostId:string;status:MatchState['status'];maxPlayers:number}
export const roomCodeSchema=z.string().regex(/^[A-Z0-9]{6}$/);
export const nameSchema=z.string().trim().min(1).max(16).regex(/^[\p{L}\p{N} _-]+$/u);
export const EVENTS={CREATE:'room:create',JOIN:'room:join',LEAVE:'room:leave',START:'match:start',INPUT:'game:input',STATE:'game:state',ROOM:'room:update',ERROR:'game:error',NOTICE:'game:notice',REMATCH:'match:rematch'} as const;
