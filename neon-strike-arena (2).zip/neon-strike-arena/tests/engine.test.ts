import {describe,it,expect} from 'vitest';
import {GameEngine} from '../server/src/game/engine.js';
import {RoomManager} from '../server/src/rooms/manager.js';
import {roomCodeSchema,inputSchema} from '../shared/protocol.js';
const input=(patch:Partial<{up:boolean;down:boolean;left:boolean;right:boolean;aimX:number;aimY:number;shoot:boolean}>={})=>({up:false,down:false,left:false,right:false,aimX:800,aimY:500,shoot:false,...patch});
function playing(){const g=new GameEngine('ABC123');g.addPlayer('a','Alpha');g.addPlayer('b','Bravo');g.start();const now=Date.now()+5100;g.tick(now);return {g,now};}
describe('protocol validation',()=>{it('accepts six-character room codes only',()=>{expect(roomCodeSchema.safeParse('A1B2C3').success).toBe(true);expect(roomCodeSchema.safeParse('A1B').success).toBe(false);});it('rejects malformed or out-of-bounds input intent',()=>{expect(inputSchema.safeParse(input()).success).toBe(true);expect(inputSchema.safeParse({...input(),aimX:99999}).success).toBe(false);expect(inputSchema.safeParse({...input(),shoot:'yes'}).success).toBe(false);});});
describe('GameEngine',()=>{
 it('adds players and enforces four-player capacity',()=>{const g=new GameEngine('ABC123');for(let i=0;i<4;i++)g.addPlayer('p'+i,'P'+i);expect(g.state.players).toHaveLength(4);expect(()=>g.addPlayer('p5','P5')).toThrow(/full/i);});
 it('requires two connected players to start',()=>{const g=new GameEngine('ABC123');g.addPlayer('a','A');expect(()=>g.start()).toThrow(/two/i);g.addPlayer('b','B');g.start();expect(g.state.status).toBe('countdown');});
 it('moves players only from validated input intent',()=>{const {g,now}=playing();const p=g.player('a')!;const x=p.x;g.setInput('a',input({right:true}));g.tick(now+100);expect(p.x).toBeGreaterThan(x);});
 it('applies projectile hits, awards kills, and respawns at full health',()=>{const {g,now}=playing();const shooter=g.player('a')!,target=g.player('b')!;shooter.x=target.x-200;shooter.y=target.y;for(let i=0;i<4;i++){g.state.projectiles.push({id:'bullet'+i,ownerId:'a',x:target.x-10,y:target.y,vx:720,vy:0,bornAt:now+i*40});g.tick(now+(i+1)*40);}expect(target.health).toBe(0);expect(shooter.kills).toBe(1);g.tick(now+2100);expect(target.health).toBe(100);});
 it('ends early when a player reaches ten kills',()=>{const {g,now}=playing();g.player('a')!.kills=10;g.tick(now+40);expect(g.state.status).toBe('finished');expect(g.state.winnerId).toBe('a');});
 it('supports a configurable match timer and rematch reset',()=>{const g=new GameEngine('ABC123',1);g.addPlayer('a','A');g.addPlayer('b','B');g.start();const now=Date.now()+5100;g.tick(now);g.tick(now+1100);expect(g.state.status).toBe('finished');g.rematch();expect(g.state.status).toBe('waiting');expect(g.state.timeLeft).toBe(1);});
});
describe('RoomManager',()=>{it('creates unique isolated six-character rooms',()=>{const m=new RoomManager();const a=m.create('p1','A','s1');const b=m.create('p2','B','s2');expect(a.code).not.toBe(b.code);expect(a.code).toHaveLength(6);expect(m.rooms.size).toBe(2);expect(a.engine.state.players).toHaveLength(1);});
 it('enforces capacity and supports disconnect/reconnect grace',()=>{const m=new RoomManager(2,180,20000);const room=m.create('p1','A','s1');m.join(room.code,'p2','B','s2');expect(()=>m.join(room.code,'p3','C','s3')).toThrow(/full/i);m.disconnect('p2');expect(room.engine.player('p2')?.connected).toBe(false);expect(m.reconnect(room.code,'p2','s2-new')).toBe(room);expect(room.engine.player('p2')?.connected).toBe(true);expect(room.socketByPlayer.get('p2')).toBe('s2-new');});
});
