# Neon Strike Arena

A real-time 2–4 player top-down browser shooter. React + TypeScript + Vite client, HTML Canvas renderer, Node/Express/Socket.IO authoritative server, and shared Zod-validated protocol.

## Requirements
- Node.js 20+
- npm 10+

## Local development
```bash
cp .env.example .env
npm install
npm run dev
```
Open http://localhost:5173 in multiple browser profiles/windows. Create a room in one, share the invitation URL or six-character code, and join from other sessions. The first player is host and starts the match when at least two players are connected.

## Production
```bash
npm install
npm run build
NODE_ENV=production PORT=3000 npm start
```
The Express process serves `dist/` and Socket.IO from the same origin. Configure the hosting service to run `npm install && npm run build` at build time and `npm start` at runtime. Set `NODE_ENV=production` and `PORT` as provided by the host. `/health` is the health check.

## Controls
- Desktop: WASD / arrow keys to move, mouse to aim, hold Space to fire.
- Mobile: left virtual joystick to move, hold FIRE to shoot; aim follows touch/pointer position over the arena.

## Game rules
- Private rooms, six-character codes, 2–4 players.
- Three-minute rounds; first to ten kills wins; otherwise most kills wins when time expires.
- 100 HP, 25 damage per hit, 260 ms server-side fire cooldown, eight active projectiles per player, 1.8 s respawn, 1.4 s spawn protection.
- 30 Hz server simulation and state broadcasts (client rendering is requestAnimationFrame).
- 20-second reconnect grace period. Reconnect uses the local player ID and room code retained in that browser's local storage.

## Architecture and security
The server owns movement, projectile simulation, collision, health, kills, respawns, timers and results. Clients submit movement/aim/fire intent only. Zod validates incoming player inputs and room/name data; input events are rate-limited to 50 Hz per player. Movement resolves against arena obstacles. The game world is 1600×1000 logical pixels and the client scales it to its canvas.

Room state is intentionally in memory for this starter. **A server restart clears rooms and active matches.** A single long-lived Node service is expected. Multiple server instances require shared room state and Socket.IO adapter/pub-sub, which are not included.

## Tests
`npm test` runs the Vitest unit suite (protocol validation, room capacity, movement, projectile damage, kill scoring, respawn, match completion, rematch, and reconnect). `npm run test:e2e` runs the Playwright suite in separate browser contexts for room creation/joining, isolation, four-player capacity, and mobile layout. `npm run build` type-checks server and client TypeScript and builds the client.

## Known starter limitations
- No persistence, accounts, moderation, matchmaking or anti-cheat beyond server authority, input validation and rate/cap constraints.
- Reconnect identity is a browser-local UUID, not an authenticated credential; do not treat it as production-grade identity.
- Room host migration is automatic after a host leaves, but reconnect state is scoped to the in-memory process.
- Visual/audio effects are intentionally lightweight and sound is currently a UI toggle placeholder.
- No public deployment is included until a hosting account/project and deployment authorization are available.
